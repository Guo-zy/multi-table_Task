 - 1.Table of student(id,name,age,sex);  
    - id student identity number
    - name student name 
    - age birthday
    - sex gender  
- 2.Table of course(id,name,teacherId);
    - id course number
    - name course name
    - teacherId teacher identity number  
- 3.Table of teacher(id,name);
    - id teacher identity number
    - name teacher name   
- 4.Table of student_course(studentId,courseId,score);
    - studentId student identity number
    - courseId course identity number
    - score

## Procedures:
**1.Import data through data.sql**  
**2.Finish the sql statements in select.sql.**
